package com.example.pokemoncard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
